document.addEventListener('DOMContentLoaded', () => {
    const button = document.getElementById('color-button');

    button.addEventListener('click', () => {
        alert('Hello World');
    });
});
